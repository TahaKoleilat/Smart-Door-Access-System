from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import img_to_array

from pymongo import MongoClient
import json
from flask import *
import cv2
import os 
from PIL import Image
import matplotlib.pyplot as plt
import numpy as np
from datetime import datetime
from flask import Flask, request
# =============================================================================
client = MongoClient("mongodb+srv://hussein:hussein@cluster0.5tafr.mongodb.net/test?retryWrites=true&w=majority", connectTimeoutMS=50000)

db = client.get_database('Smart_Door')
records=db.Sudents


documents=records.find()
ID=1;
json_list1 = []
for document in documents:
    json_list1.append(json.dumps(document, default=str))
    
print(json_list1)




app = Flask(__name__)

    
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Perform authentication here
        if username=="admin" and password=="admin" :
            return redirect('http://localhost:5000/display')
        else:
            # Authentication failed, show error message
            error = 'Invalid username or password. Please try again.'
            return render_template('login.html', error=error)
        
    else:
        return render_template('login.html')
    
@app.route('/register')
def display_json():
    # Assume that `json_list` is a list of Python dictionaries containing the JSON data
    client = MongoClient("mongodb+srv://hussein:hussein@cluster0.5tafr.mongodb.net/?retryWrites=true&w=majority")
    db = client.get_database('Smart_Door')
    records=db.Sudents
    documents=records.find()

    json_list = []
    for record in documents:
        # Use json.dumps() to convert the record to a JSON string
        json_string = json.dumps(record, default=str)
        # Use json.loads() to convert the JSON string to a JSON object
        json_object = json.loads(json_string)
        # Append the JSON object to the list
        json_list.append(json_object)
    
    print(json_list)
    return render_template('Register.html', json_list=json_list)




@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        Name= request.form["Name"]
        ID= request.form["ID"]
        # get me the value of the radio buttion 
        Vaccinated=request.form["options"]
        print(Vaccinated)
        
    

        # Specify the file path where you want to save the image
        query = {'Student_Id': ID}

# check if document already exists
        existing_doc = records.find_one(query)
        if existing_doc:
            return ' already registered'
            
        else:
            data={ "Student_Id":ID, "Name":Name, "Vaccinated":Vaccinated}
            json_data = json.dumps(data)
            records.insert_one(json.loads(json_data))
        

        return redirect(url_for('upload_video', ID=ID))
    else:
        return render_template('upload.html')

@app.route('/upload1', methods=['GET','POST'])
def upload_video():

    if  request.method=="POST":
        if 'video' not in request.files:
            return 'No video file found in the request', 400
        ID = request.form.get('id')
        print("The ID passed in the URL is:", ID)
        video_file = request.files['video']
        video_file.save("ImagesDB/"+ID+'.mp4') # save the video file in the current directory
        
        # read video file
        cap = cv2.VideoCapture("ImagesDB/"+ID+'.mp4')
        
        folder_path = f'ImagesDb/{ID}/'
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)
        # extract frames
        count = 0
        while cap.isOpened() and count < 5:
            ret, frame = cap.read()
            if not ret:
                break
            cv2.imwrite(f'{folder_path}frame_{count}.jpg', frame)
            count += 1    
        # release resources
        cap.release()
        file_path = '/path/to/file.txt'
        if os.path.exists("ImagesDB/"+ID+'.mp4'):
            os.remove("ImagesDB/"+ID+'.mp4')
        return redirect(url_for('display_json'))
    else:
        ID= request.args.get('ID')
        return render_template('video.html')

app.run()